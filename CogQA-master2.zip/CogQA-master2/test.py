import json
with open('./data/hotpot_train_v1.1_refined.json', 'r') as fin:
    train_set = json.load(fin)

with open('./data/hotpot_train_v1.1_refined_50.json', 'w') as fin:
    train_set = json.dump(train_set[:50],fin)

